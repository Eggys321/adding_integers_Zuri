first_number = int(input('Type first number '))
second_number = int(input('Type second number '))
addtion = print(first_number + second_number)



